package com.example.tp1_musique;

public interface ObservateurChangement {

    public void changement(ListeChansons music);
}
