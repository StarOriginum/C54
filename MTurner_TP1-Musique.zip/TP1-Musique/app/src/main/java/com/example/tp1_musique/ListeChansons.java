package com.example.tp1_musique;

import java.util.ArrayList;
import java.util.List;

public class ListeChansons {

    private List<Chansons> music = new ArrayList<>();

    public List<Chansons> getMusic() {
        return music;
    }
}
