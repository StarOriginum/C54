package com.example.examen1_kt

data class Langages(var nom:String, var classement2024:Int, var classement2019:Int, var classement2012:Int) {

}