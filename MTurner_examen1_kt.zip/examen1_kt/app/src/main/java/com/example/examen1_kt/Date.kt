package com.example.examen1_kt

import java.io.Serializable
import java.time.LocalDateTime

data class Date (var dateTime: LocalDateTime): Serializable {
}